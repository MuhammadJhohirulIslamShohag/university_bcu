
'''
Ex:01
Write a Python script that will calculate the square root of the equation B*B + 4 * A *
C. (hints you can use three variables to store the values of A, B and C). Note: to
calculate square root of a number x, you need to implement the following x**(1/2.0) 

'''
a = 2
b=3
c = 5
x = b*b + 4 * a * c 
squareRootValue = x**(1/2.0)
print(squareRootValue)









